/** 由于打包完成后要进行 文件操作需要工具
 * 1.需要file 工具
 * 2.要打包成zip文件需要 glup
 * 3.要进行文件删除需要路径 这个时候需要路径管理包
*/
var gulp = require('gulp');
var gulpZip = require('gulp-zip');
var moment = require('moment');
var fs = require('fs-extra');
var Creatorcommand = require('./Creatorcommand');
var path = require('path');

// 打包
const zip = {
  projectPath: '../', // 打包的目录路径
  generatePath: '../150/', // 项目移动到的路径
  projectName: '', // 项目名称
  platForm: '',     // 平台
  debug: '', // 是打debug还是不打
};
var project = '';
var jsonPath = path.join('./project.json');
zip.setData = (data) => {
  console.log('当前解析的数据源' + JSON.stringify(data));
  zip.projectName = data.projectName;
  zip.platForm = data.platForm;
  zip.debug = data.debug;
};
zip.tak = () => {
  zip.readJsonToData();
  project = path.join(zip.projectPath, '/build/web-mobile');
  console.log('当前的构建目录' + project);
  if (fs.existsSync(project)) {
    console.log('当前已经存在');
    fs.removeSync(project);
  }
  Creatorcommand(zip.projectPath, zip.platForm, zip.callback, zip.debug);
};
zip.callback = () => {
  if (fs.existsSync(project)) {
    console.log('开始移动路径 当前的路径' + project);
    console.log('开始压缩');
    zip.generatePath = zip.debug ? path.join(zip.projectPath, 'test/') : zip.join(zip.projectPath, 'release/');
    var zipPath = path.join(zip.generatePath, zip.projectName) + moment().format('YYYYMMDD-HHmmss') + '.zip';
    console.log('压缩的路径' + zipPath);
    gulp.src(path.join(project, '/**/*.*')).pipe(gulpZip(zipPath, { compress: false })).pipe(gulp.dest(project));
  } else {
    console.log('当前打包可能失败或者文件名不确定将重新打包');
    zip.tak();
  }
};
zip.readJsonToData = () => {
  var jsonData = {};
  if (fs.existsSync(jsonPath)) {
    console.log('当前配置文件路径存在开始读取');
    jsonData = fs.readJsonSync(jsonPath, 'utf8', function (err) {
      throw err;
    });
    console.log('当前的配置文件' + JSON.stringify(jsonData));
    zip.setData(jsonData);
  } else {
    throw '配置文件project.json不存在请进行配置';
  }
};
zip.tak();
