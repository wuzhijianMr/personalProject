/**
 *按照大神写法 整理思路  我现在需要 四样东西
 *1.判断当前是什么平台 应为cocoscreator在windows和macOS上使用命令不一样     os
 *2.需要一个路径管理类来帮助我更好的拼接管理路径 在不同平台下路径的表现形式不一样                            path
 *3.需要一个在本地夸平台调用系统命令的工具                                  child_process 这里只需要他的执行本地命令的方法  spawn
 *4.需要一个解决应为平台不懂可能乱码的工具                                  iconv-lite
  */

/** 打包命令行示例
 * Mac - /Applications/CocosCreator.app/Contents/MacOS/CocosCreator --path projectPath --build "platform=android;debug=true"
   Windows - CocosCreator/CocosCreator.exe --path projectPath --build "platform=android;debug=true"
   如果希望在构建完原生项目后自动开始编译的话，可以使用 autoCompile 参数
   --build "autoCompile=true"
   也可以自己开始编译项目，--compile 命令的参数和 --build 命令的参数一致
   --compile "platform=android;debug=true"
   命令参数：
   configPath - 参数文件路径。如果定义了这个字段，那么构建时将会按照 json 文件格式来加载这个数据，并作为构建参数
*/
var iconv = require('iconv-lite');
var spawn = require('child_process').spawn;
var os = require('os');
var path = require('path');

module.exports = function (projectPath, platform, callback, debug, optas = {}) {
  let cmd = '';
  if (os.platform() === 'darwin') {
    cmd = '/Applications/CocosCreator.app/Contents/MacOS/CocosCreator';
  }
  if (os.platform() === 'win32') {
    cmd = 'CocosCreator.exe';
  }

  const pathParameter = path.join(projectPath);
  const buildParametr = path.join(`platform=${platform};debug=${debug};configPath=${projectPath}/setting/builder.json`);
  console.log('当前拼接的参数路径===' + buildParametr);
  const agrs = ['--path', pathParameter, '--build', buildParametr];

  const ls = spawn(cmd, agrs, optas);

  ls.stdout.on('data', function (data) {
    console.log(iconv.decode(data, 'gbk'));
  });

  ls.stderr.on('data', function (data) {
    console.log(iconv.decode(data, 'gbk').red);
  });

  ls.on('exit', function (code) {
    callback(null, code);
  });
};
